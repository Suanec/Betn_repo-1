#!/usr/bin/env bash

sh bin.sh -j dataflow-w2v.jar -x pipeline.xml  -n $1
