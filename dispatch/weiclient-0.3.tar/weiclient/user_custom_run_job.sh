#!/bin/sh
echo 'this is an example script.'
echo 'hello world, this is from script.'
