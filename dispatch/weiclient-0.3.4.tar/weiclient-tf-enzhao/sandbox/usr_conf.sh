#!/bin/bash
#
# define your args in this script
# 

# dirs 

# USER dirs
CUR_DIR="$( cd "$( dirname "$0" )" && pwd )"
USER_DIR=${CUR_DIR}/usr/
DATA_DIR=${CUR_DIR}/data/
MODEL_DIR=${CUR_DIR}/model/
LOG_DIR=${CUR_DIR}/log/

# user edit
# job define
JOB_NAME=lihan3_test

# run env option
RUN_ENV=docker 			# local | docker 

## docker run opt ,if RUN_ENV is docker 
DOCKER_IMAGE=tensorflow/tensorflow:latest

# train data option,

TRAIN_DATA=train.data

# model data option 

MODEL_DATA=train.model

# local  run command 


if [ "$RUN_ENV" == "local" ];then

	# the args you may use
	TRAIN_DATA_PATH=${DATA_DIR}/${TRAIN_DATA}
	MODEL_DATA_PATH=${MODEL_DIR}/${MODEL_DATA}
	LOG_DATA_PATH=${LOG_DIR}
	
	SCRIPT_PATH=${USER_DIR}

elif [ "$RUN_ENV" == "docker" ];then
	
	# the args you may use
	TRAIN_DATA_PATH=/data1/sandbox/data/${TRAIN_DATA}
	MODEL_DATA_PATH=/data1/sandbox/model/${MODEL_DATA}
	LOG_DATA_PATH=/data1/sandbox/log/
	
	SCRIPT_PATH=/data1/sandbox/usr/
fi

YOURSELF_ARGS=""

RUN_SCRIPT="start.sh -i $TRAIN_DATA_PATH -o $MODEL_DATA_PATH -l $LOG_DATA_PATH $YOURSELF_ARGS"
# you define yourself or define RUN_SCRIPT and ARGS
RUN_CMD="sh ${SCRIPT_PATH}${RUN_SCRIPT}"
