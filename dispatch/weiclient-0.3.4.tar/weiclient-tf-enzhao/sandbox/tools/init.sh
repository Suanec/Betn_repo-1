#!/bin/bash
TOOLS_DIR="$( cd "$( dirname "$0" )" && pwd )"
source ${TOOLS_DIR}/../usr_conf.sh


RSYNC_DIR="10.77.29.68::backup/data/${JOB_NAME}/train_data"
echo "rsync $RSYNC_DIR/$TRAIN_DATA ../data/$TRAIN_DATA"
