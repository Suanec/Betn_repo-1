#!/usr/bin/env bash

sh bin.sh -j dataflow-Tron.jar  -x pipeline.xml.testLR.xml -n $1
