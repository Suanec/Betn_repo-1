#!/bin/bash

cmd="sh ./lib/client.sh -f ./conf/weiclient.conf.template "
echo $cmd
$cmd
