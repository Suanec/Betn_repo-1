#!/bin/bash

TOOLS_DIR="$( cd "$( dirname "$0" )" && pwd )"
source ${TOOLS_DIR}/../usr_conf.sh

RSYNC_PATH=10.77.29.68::backup/data/${JOB_NAME}/model
MODEL_DONE=0

#echo "rsync -vzrtopg --progress ../model/${MODEL_DATA} ${RSYNC_PATH}/$MODEL_DATA"
docker rm $JOB_NAME
while true
do
	if [ -f ../model/${MODEL_DATA} ];then
		sleep 100	
		echo "rsync -vzrtopg --progress ../model/${MODEL_DATA} ${RSYNC_PATH}/$MODEL_DATA"
		echo "curl ..."
		MODEL_DONE=1
	fi
	MODEL_DONE=1
	echo "model not exist"
	if [ $MODEL_DONE -eq 1 ];then
		break
	fi

	sleep 10
done
