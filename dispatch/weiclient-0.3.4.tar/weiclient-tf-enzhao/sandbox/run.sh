#!/bin/bash

CUR_DIR="$( cd "$( dirname "$0" )" && pwd )"
source ${CUR_DIR}/usr_conf.sh


INIT_EXEC="sh $CUR_DIR/tools/init.sh"
#echo $INIT_EXEC
$INIT_EXEC


if [ "$RUN_ENV" == "docker" ];then
	EXEC="docker run --name ${JOB_NAME} -v ${DATA_DIR}:/data1/sanbox/data -v ${MODEL_DIR}:/data1/sandbox/model -v ${USER_DIR}:/data1/sandbox/usr -v ${LOG_DIR}:/data1/sandbox/log --net host $DOCKER_IMAGE $RUN_CMD"
elif [ "$RUN_ENV" == "local" ];then
	EXEC="$RUN_CMD"
fi
echo $EXEC
$EXEC

FINISH_EXEC="sh $CUR_DIR/tools/finish.sh"
#echo $FINISH_EXEC
$FINISH_EXEC
