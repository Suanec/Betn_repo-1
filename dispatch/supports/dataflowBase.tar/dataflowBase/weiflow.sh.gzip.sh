#!/usr/bin/env bash

sh bin.sh -j dataflow-outGzip.jar -x pipeline.xml.gzip -n $1
