while getopts "i:o:l:" arg
#    if [ $arg = "" ]; then
#       show_usage
#       exit 0
#    fi
do
  case ${arg} in
      i) train_data=${OPTARG};;
      o) model_data=${OPTARG};;
      l) log_path=${OPTARG};;
    esac
done

echo " train data :$train_data"
echo " model data :$model_data"
echo " log path : $log_path"

# user's code 

echo "hello" > $log_path/log
