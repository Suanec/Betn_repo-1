echo "hello world from script"
pwd
echo "without absolute path"
