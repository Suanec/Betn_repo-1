#!/usr/bin/env bash

sh bin.sh -j dataflow-w2v -x pipeline.xml  -n $1
